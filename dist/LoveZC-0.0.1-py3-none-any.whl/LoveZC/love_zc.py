
def love_zc():
    print("She was my North, my South, my East and West,\n"
    "My working week and my Sunday rest,\n"
    "My noon, my midnight, my talk, my song;\n"
    "I thought that love would last forever: I was wrong.")
    return 0




